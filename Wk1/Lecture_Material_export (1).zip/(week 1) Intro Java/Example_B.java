/**
  Identifiers are the names that identify the elements such as classes,
 * methods, and variables in a program.
 * Types of identifiers:
 * 1) Programmer defined: Example, args, janDays
 * 2) Other-programmer defined (built in "libraries"):
 *    System, String, printLn
 * 3) Reserved (or key) words: public, class, void
 *
 * Identifier rules:
 * - case-sensitive
 * - starts with a letter
 * - Subsequent characters may be letters, digits, or underscore characters
 * https://docs.oracle.com/javase/tutorial/java/nutsandbolts/variables.html
 */
public class Example_B {
    public static void main(String[] args) {
        //constant "variable"
        final int months = 12;
        //months = 13; // not legal
        // declare a variable with a type of int (integer)
        // and an identifier of 'janDays'
        int janDays;
        janDays = 1;

        // assign the value of an expression to the janDays variable
        // this is called an assignment statement
        janDays = 31;

        double myDouble = 1.2;
        boolean myBoolean = true;
        myBoolean = false;

        char myChar = 'A';
        myChar = '!';

        Example_B myExample = new Example_B();
        System.out.println(myExample);
        myExample = new Example_B();
        System.out.println(myExample);
        String myString = "my string";
        System.out.println(myString);

        System.out.println("January has " + janDays + " days.");
        System.out.println(myDouble);
        System.out.println(myBoolean);
        System.out.println(myChar);





    }
}

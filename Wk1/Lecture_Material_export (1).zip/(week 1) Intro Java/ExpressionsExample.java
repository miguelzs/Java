/**
* Precedence rules:
* 0) ++ and -- (increment and decrement); ex: a++
* 1) +- unary opperators, ex: -2 or -(3+4); works right -> left
* 2) * / % ex: 3*4 or 12%5; works left -> right
* 3) + - (add and subtract), ex: 3 + 2 or 5-8; works left -> right
* 4) = (assignment); ex total = 4+5; works right -> left
* 5) += -= %= /= composite operators; ex sum += 12 --> sum = (sum + 12)
**/

public class ExpressionsExample {
    public static void main(String[] args) {
        double total = 2 + 3 * 5; // 25.0? or 17.0?
        System.out.println(total);
        double anotherValue = 16 / 7 + 2 - 4;
        System.out.println(anotherValue);

        // force a certain order with parentheses
        anotherValue = (16 / (7 + 2)) - 4;
        System.out.println(anotherValue);
        int aNumber = 1;
        System.out.println("aNumber = " + aNumber);

        aNumber = aNumber++; // this is called postincrement  => op + assignment op

        // What happens:
        //int temp = aNumber;
        //aNumber = aNumber +1; //increment
        //aNumber = temp; // then assignment


        //aNumber = (aNumber++);
        System.out.println("aNumber = aNumber++ = " + aNumber);
        aNumber = 4 + ++aNumber; // this is called preincrement
        System.out.println("4 + ++aNumber = " + aNumber);

        aNumber = 4 + aNumber++;
        System.out.println("4 + aNumber++ = " +aNumber);

        int x = 8-3*4+6/2;
        System.out.println(x);
        int y = 4/2-3/5*3;
        System.out.println(y);
    }
}

public class MyCalculator {
    public static void main(String[] args) {
        // Do not modify the following line.
        int myInt = Integer.parseInt(args[0]);
        // Print out the number
        System.out.println("The number is " + myInt);
        //postfix increment
        System.out.println("Now, the number is " + myInt++);
        //prefix increment
        System.out.println("Now part 2, the number is " + (++myInt));

        // Print out the digit divided by 2
        System.out.println("The result of (double)(myInt / 2)is " + (double)(myInt / 2));

        // Print out the digit as a double divided by 2
        System.out.println("The result of (double)myInt / 2 is " + (double)myInt / 2);
        // Print out the digit divided by 2.0
        System.out.println("The result myInt / 2.0 is " + myInt / 2.0);

        // Print out the digit as a double
        System.out.println("The double is " + (double) myInt);

        // What's going on here:
        System.out.println("Now part 3, the number is " + (++myInt/2.0));
        System.out.println("Now part 4, the number is " + (myInt++/2.0));
        System.out.println("myInt: " + myInt);
    }
}
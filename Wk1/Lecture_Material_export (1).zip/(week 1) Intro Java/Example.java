/*
 * Identifiers are the names that identify the elements such as classes,
 * methods, and variables in a program.
 * Types of identifiers:
 * 1) Programmer defined: Example, args, janDays
 * 2) Other-programmer defined (built in "libraries"):
 *    System, String, printLn
 * 3) Reserved (or key) words: public, class, void
 *
 * Identifier rules:
 * - case-sensitive
 * - starts with a letter
 * - Subsequent characters may be letters, digits, or underscore characters
 * https://docs.oracle.com/javase/tutorial/java/nutsandbolts/variables.html
 */
public class Example {
    public static void main(String[] args) {
        // declare a variable with a type of int (integer)
        // and an identifier of 'janDays'
        int janDays;
        // assign the value of an expression to the janDays variable
        // this is called an assignment statement
        janDays = 30 + 1;
        System.out.println("January has " + janDays + " days.");
    }
}
